
function validateform(){
	var firstname=document.myform.firstname.value;  
	var test=firstname.length;
	if(test<4){
		alert("First Name must be 4 character");
		return false;
	}
	
	
	var lastname=document.myform.lastname.value;  
	var test=lastname.length;
	if(test<4){
		alert("Last Name must be 4 character");
		return false;
	}
	
	
	var phonenumber=document.myform.phonenumber.value;  
	var test=phonenumber.length;
    if (isNaN(phonenumber)){  
    alert("numeric value only and 11 character");
    return false;  
    }
	
	var a=document.myform.email.value; 
	if(a.indexOf('@')<=0){
		var b=document.getElementsByClassName("massage")[0];
		b.innerHTML="**first position @ Invalid";
		return false;
		
		
	}
	
	if(a.charAt(a.length-4)!=='.'&& a.charAt(a.length-3)!=='.'){
		var b=document.getElementsByClassName("massage")[0];
		b.innerHTML="**Invalid . position";
		return false;
	}
	b.classList.add(massage);
}


